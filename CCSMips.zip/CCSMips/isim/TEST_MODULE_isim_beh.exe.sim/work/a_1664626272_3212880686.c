/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/user/Documents/task/CCSMips/DEC.vhd";



static void work_a_1664626272_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 9907);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 9913);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 9919);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 9925);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 9931);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 9937);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 9943);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 6728);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6504);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 6728);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 6728);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 6728);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 6728);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 6728);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 6728);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 6728);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_1(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 9949);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 9955);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 9961);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 9967);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 9973);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 9979);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 9985);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 6792);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6520);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 6792);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 6792);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 6792);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 6792);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 6792);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 6792);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 6792);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_2(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 9991);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 9997);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10003);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10009);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10015);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10021);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10027);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 6856);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6536);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 6856);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 6856);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 6856);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 6856);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 6856);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 6856);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 6856);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_3(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10033);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 10039);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10045);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10051);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10057);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10063);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10069);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 6920);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6552);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 6920);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 6920);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 6920);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 6920);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 6920);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 6920);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 6920);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_4(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10075);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 10081);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10087);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10093);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10099);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10105);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10111);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 6984);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6568);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 6984);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 6984);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 6984);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 6984);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 6984);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 6984);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 6984);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_5(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10117);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 10123);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10129);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10135);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10141);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10147);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10153);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 7048);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6584);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 7048);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 7048);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 7048);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 7048);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 7048);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 7048);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 7048);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_6(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(76, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10159);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 10165);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10171);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10177);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10183);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10189);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10195);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 7112);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6600);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 7112);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 7112);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 7112);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 7112);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 7112);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 7112);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 7112);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_7(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(84, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10201);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 10207);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10213);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10219);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10225);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10231);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10237);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 7176);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6616);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 7176);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 7176);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 7176);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 7176);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 7176);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 7176);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 7176);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_8(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t75;
    unsigned char t76;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    unsigned char t81;
    char *t82;
    char *t83;
    unsigned char t85;
    unsigned int t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    unsigned char t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned char t97;
    char *t98;
    char *t99;
    unsigned char t101;
    unsigned int t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    unsigned char t107;
    unsigned char t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;

LAB0:    xsi_set_current_line(92, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10243);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1192U);
    t19 = *((char **)t18);
    t18 = (t0 + 10249);
    t21 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t21 = 0;

LAB21:    if (t21 == 1)
        goto LAB16;

LAB17:    t17 = (unsigned char)0;

LAB18:    if (t17 != 0)
        goto LAB14;

LAB15:    t34 = (t0 + 1192U);
    t35 = *((char **)t34);
    t34 = (t0 + 10255);
    t37 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t37 = 0;

LAB32:    if (t37 == 1)
        goto LAB27;

LAB28:    t33 = (unsigned char)0;

LAB29:    if (t33 != 0)
        goto LAB25;

LAB26:    t50 = (t0 + 1192U);
    t51 = *((char **)t50);
    t50 = (t0 + 10261);
    t53 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t53 = 0;

LAB43:    if (t53 == 1)
        goto LAB38;

LAB39:    t49 = (unsigned char)0;

LAB40:    if (t49 != 0)
        goto LAB36;

LAB37:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 10267);
    t69 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t69 = 0;

LAB54:    if (t69 == 1)
        goto LAB49;

LAB50:    t65 = (unsigned char)0;

LAB51:    if (t65 != 0)
        goto LAB47;

LAB48:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 10273);
    t85 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t85 = 0;

LAB65:    if (t85 == 1)
        goto LAB60;

LAB61:    t81 = (unsigned char)0;

LAB62:    if (t81 != 0)
        goto LAB58;

LAB59:    t98 = (t0 + 1192U);
    t99 = *((char **)t98);
    t98 = (t0 + 10279);
    t101 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t101 = 0;

LAB76:    if (t101 == 1)
        goto LAB71;

LAB72:    t97 = (unsigned char)0;

LAB73:    if (t97 != 0)
        goto LAB69;

LAB70:
LAB80:    t113 = (t0 + 7240);
    t114 = (t113 + 56U);
    t115 = *((char **)t114);
    t116 = (t115 + 56U);
    t117 = *((char **)t116);
    *((unsigned char *)t117) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t113);

LAB2:    t118 = (t0 + 6632);
    *((int *)t118) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 7240);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t25 = (t0 + 7240);
    t29 = (t25 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t25);
    goto LAB2;

LAB16:    t25 = (t0 + 1032U);
    t26 = *((char **)t25);
    t27 = *((unsigned char *)t26);
    t28 = (t27 == (unsigned char)3);
    t17 = t28;
    goto LAB18;

LAB19:    t22 = 0;

LAB22:    if (t22 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB20;

LAB24:    t22 = (t22 + 1);
    goto LAB22;

LAB25:    t41 = (t0 + 7240);
    t45 = (t41 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB27:    t41 = (t0 + 1032U);
    t42 = *((char **)t41);
    t43 = *((unsigned char *)t42);
    t44 = (t43 == (unsigned char)3);
    t33 = t44;
    goto LAB29;

LAB30:    t38 = 0;

LAB33:    if (t38 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB31;

LAB35:    t38 = (t38 + 1);
    goto LAB33;

LAB36:    t57 = (t0 + 7240);
    t61 = (t57 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    *((unsigned char *)t64) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t57);
    goto LAB2;

LAB38:    t57 = (t0 + 1032U);
    t58 = *((char **)t57);
    t59 = *((unsigned char *)t58);
    t60 = (t59 == (unsigned char)3);
    t49 = t60;
    goto LAB40;

LAB41:    t54 = 0;

LAB44:    if (t54 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB42;

LAB46:    t54 = (t54 + 1);
    goto LAB44;

LAB47:    t73 = (t0 + 7240);
    t77 = (t73 + 56U);
    t78 = *((char **)t77);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    *((unsigned char *)t80) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t73);
    goto LAB2;

LAB49:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t75 = *((unsigned char *)t74);
    t76 = (t75 == (unsigned char)3);
    t65 = t76;
    goto LAB51;

LAB52:    t70 = 0;

LAB55:    if (t70 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB53;

LAB57:    t70 = (t70 + 1);
    goto LAB55;

LAB58:    t89 = (t0 + 7240);
    t93 = (t89 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t89);
    goto LAB2;

LAB60:    t89 = (t0 + 1032U);
    t90 = *((char **)t89);
    t91 = *((unsigned char *)t90);
    t92 = (t91 == (unsigned char)3);
    t81 = t92;
    goto LAB62;

LAB63:    t86 = 0;

LAB66:    if (t86 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t87 = (t83 + t86);
    t88 = (t82 + t86);
    if (*((unsigned char *)t87) != *((unsigned char *)t88))
        goto LAB64;

LAB68:    t86 = (t86 + 1);
    goto LAB66;

LAB69:    t105 = (t0 + 7240);
    t109 = (t105 + 56U);
    t110 = *((char **)t109);
    t111 = (t110 + 56U);
    t112 = *((char **)t111);
    *((unsigned char *)t112) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t105);
    goto LAB2;

LAB71:    t105 = (t0 + 1032U);
    t106 = *((char **)t105);
    t107 = *((unsigned char *)t106);
    t108 = (t107 == (unsigned char)3);
    t97 = t108;
    goto LAB73;

LAB74:    t102 = 0;

LAB77:    if (t102 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t103 = (t99 + t102);
    t104 = (t98 + t102);
    if (*((unsigned char *)t103) != *((unsigned char *)t104))
        goto LAB75;

LAB79:    t102 = (t102 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}

static void work_a_1664626272_3212880686_p_9(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    char *t20;
    char *t21;
    unsigned char t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned char t37;
    char *t38;
    char *t39;
    unsigned char t41;
    unsigned int t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned char t47;
    unsigned char t48;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    unsigned char t55;
    char *t56;
    char *t57;
    unsigned char t59;
    unsigned int t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    unsigned char t66;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    unsigned char t73;
    char *t74;
    char *t75;
    unsigned char t77;
    unsigned int t78;
    char *t79;
    char *t80;
    char *t81;
    char *t82;
    unsigned char t83;
    unsigned char t84;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    unsigned char t91;
    char *t92;
    char *t93;
    unsigned char t95;
    unsigned int t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    unsigned char t101;
    unsigned char t102;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    unsigned char t109;
    char *t110;
    char *t111;
    unsigned char t113;
    unsigned int t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;
    unsigned char t119;
    unsigned char t120;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    char *t126;
    char *t127;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;

LAB0:    xsi_set_current_line(100, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 10285);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t20 = (t0 + 1192U);
    t21 = *((char **)t20);
    t20 = (t0 + 10293);
    t23 = 1;
    if (6U == 6U)
        goto LAB19;

LAB20:    t23 = 0;

LAB21:    if (t23 == 1)
        goto LAB16;

LAB17:    t19 = (unsigned char)0;

LAB18:    if (t19 != 0)
        goto LAB14;

LAB15:    t38 = (t0 + 1192U);
    t39 = *((char **)t38);
    t38 = (t0 + 10301);
    t41 = 1;
    if (6U == 6U)
        goto LAB30;

LAB31:    t41 = 0;

LAB32:    if (t41 == 1)
        goto LAB27;

LAB28:    t37 = (unsigned char)0;

LAB29:    if (t37 != 0)
        goto LAB25;

LAB26:    t56 = (t0 + 1192U);
    t57 = *((char **)t56);
    t56 = (t0 + 10309);
    t59 = 1;
    if (6U == 6U)
        goto LAB41;

LAB42:    t59 = 0;

LAB43:    if (t59 == 1)
        goto LAB38;

LAB39:    t55 = (unsigned char)0;

LAB40:    if (t55 != 0)
        goto LAB36;

LAB37:    t74 = (t0 + 1192U);
    t75 = *((char **)t74);
    t74 = (t0 + 10317);
    t77 = 1;
    if (6U == 6U)
        goto LAB52;

LAB53:    t77 = 0;

LAB54:    if (t77 == 1)
        goto LAB49;

LAB50:    t73 = (unsigned char)0;

LAB51:    if (t73 != 0)
        goto LAB47;

LAB48:    t92 = (t0 + 1192U);
    t93 = *((char **)t92);
    t92 = (t0 + 10325);
    t95 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t95 = 0;

LAB65:    if (t95 == 1)
        goto LAB60;

LAB61:    t91 = (unsigned char)0;

LAB62:    if (t91 != 0)
        goto LAB58;

LAB59:    t110 = (t0 + 1192U);
    t111 = *((char **)t110);
    t110 = (t0 + 10333);
    t113 = 1;
    if (6U == 6U)
        goto LAB74;

LAB75:    t113 = 0;

LAB76:    if (t113 == 1)
        goto LAB71;

LAB72:    t109 = (unsigned char)0;

LAB73:    if (t109 != 0)
        goto LAB69;

LAB70:
LAB80:    t127 = (t0 + 10341);
    t129 = (t0 + 7304);
    t130 = (t129 + 56U);
    t131 = *((char **)t130);
    t132 = (t131 + 56U);
    t133 = *((char **)t132);
    memcpy(t133, t127, 2U);
    xsi_driver_first_trans_fast_port(t129);

LAB2:    t134 = (t0 + 6648);
    *((int *)t134) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 10291);
    t14 = (t0 + 7304);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t9, 2U);
    xsi_driver_first_trans_fast_port(t14);
    goto LAB2;

LAB5:    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t27 = (t0 + 10299);
    t32 = (t0 + 7304);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    memcpy(t36, t27, 2U);
    xsi_driver_first_trans_fast_port(t32);
    goto LAB2;

LAB16:    t27 = (t0 + 1032U);
    t28 = *((char **)t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)3);
    t19 = t30;
    goto LAB18;

LAB19:    t24 = 0;

LAB22:    if (t24 < 6U)
        goto LAB23;
    else
        goto LAB21;

LAB23:    t25 = (t21 + t24);
    t26 = (t20 + t24);
    if (*((unsigned char *)t25) != *((unsigned char *)t26))
        goto LAB20;

LAB24:    t24 = (t24 + 1);
    goto LAB22;

LAB25:    t45 = (t0 + 10307);
    t50 = (t0 + 7304);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    t53 = (t52 + 56U);
    t54 = *((char **)t53);
    memcpy(t54, t45, 2U);
    xsi_driver_first_trans_fast_port(t50);
    goto LAB2;

LAB27:    t45 = (t0 + 1032U);
    t46 = *((char **)t45);
    t47 = *((unsigned char *)t46);
    t48 = (t47 == (unsigned char)3);
    t37 = t48;
    goto LAB29;

LAB30:    t42 = 0;

LAB33:    if (t42 < 6U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t43 = (t39 + t42);
    t44 = (t38 + t42);
    if (*((unsigned char *)t43) != *((unsigned char *)t44))
        goto LAB31;

LAB35:    t42 = (t42 + 1);
    goto LAB33;

LAB36:    t63 = (t0 + 10315);
    t68 = (t0 + 7304);
    t69 = (t68 + 56U);
    t70 = *((char **)t69);
    t71 = (t70 + 56U);
    t72 = *((char **)t71);
    memcpy(t72, t63, 2U);
    xsi_driver_first_trans_fast_port(t68);
    goto LAB2;

LAB38:    t63 = (t0 + 1032U);
    t64 = *((char **)t63);
    t65 = *((unsigned char *)t64);
    t66 = (t65 == (unsigned char)3);
    t55 = t66;
    goto LAB40;

LAB41:    t60 = 0;

LAB44:    if (t60 < 6U)
        goto LAB45;
    else
        goto LAB43;

LAB45:    t61 = (t57 + t60);
    t62 = (t56 + t60);
    if (*((unsigned char *)t61) != *((unsigned char *)t62))
        goto LAB42;

LAB46:    t60 = (t60 + 1);
    goto LAB44;

LAB47:    t81 = (t0 + 10323);
    t86 = (t0 + 7304);
    t87 = (t86 + 56U);
    t88 = *((char **)t87);
    t89 = (t88 + 56U);
    t90 = *((char **)t89);
    memcpy(t90, t81, 2U);
    xsi_driver_first_trans_fast_port(t86);
    goto LAB2;

LAB49:    t81 = (t0 + 1032U);
    t82 = *((char **)t81);
    t83 = *((unsigned char *)t82);
    t84 = (t83 == (unsigned char)3);
    t73 = t84;
    goto LAB51;

LAB52:    t78 = 0;

LAB55:    if (t78 < 6U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t79 = (t75 + t78);
    t80 = (t74 + t78);
    if (*((unsigned char *)t79) != *((unsigned char *)t80))
        goto LAB53;

LAB57:    t78 = (t78 + 1);
    goto LAB55;

LAB58:    t99 = (t0 + 10331);
    t104 = (t0 + 7304);
    t105 = (t104 + 56U);
    t106 = *((char **)t105);
    t107 = (t106 + 56U);
    t108 = *((char **)t107);
    memcpy(t108, t99, 2U);
    xsi_driver_first_trans_fast_port(t104);
    goto LAB2;

LAB60:    t99 = (t0 + 1032U);
    t100 = *((char **)t99);
    t101 = *((unsigned char *)t100);
    t102 = (t101 == (unsigned char)3);
    t91 = t102;
    goto LAB62;

LAB63:    t96 = 0;

LAB66:    if (t96 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t97 = (t93 + t96);
    t98 = (t92 + t96);
    if (*((unsigned char *)t97) != *((unsigned char *)t98))
        goto LAB64;

LAB68:    t96 = (t96 + 1);
    goto LAB66;

LAB69:    t117 = (t0 + 10339);
    t122 = (t0 + 7304);
    t123 = (t122 + 56U);
    t124 = *((char **)t123);
    t125 = (t124 + 56U);
    t126 = *((char **)t125);
    memcpy(t126, t117, 2U);
    xsi_driver_first_trans_fast_port(t122);
    goto LAB2;

LAB71:    t117 = (t0 + 1032U);
    t118 = *((char **)t117);
    t119 = *((unsigned char *)t118);
    t120 = (t119 == (unsigned char)3);
    t109 = t120;
    goto LAB73;

LAB74:    t114 = 0;

LAB77:    if (t114 < 6U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t115 = (t111 + t114);
    t116 = (t110 + t114);
    if (*((unsigned char *)t115) != *((unsigned char *)t116))
        goto LAB75;

LAB79:    t114 = (t114 + 1);
    goto LAB77;

LAB81:    goto LAB2;

}


extern void work_a_1664626272_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1664626272_3212880686_p_0,(void *)work_a_1664626272_3212880686_p_1,(void *)work_a_1664626272_3212880686_p_2,(void *)work_a_1664626272_3212880686_p_3,(void *)work_a_1664626272_3212880686_p_4,(void *)work_a_1664626272_3212880686_p_5,(void *)work_a_1664626272_3212880686_p_6,(void *)work_a_1664626272_3212880686_p_7,(void *)work_a_1664626272_3212880686_p_8,(void *)work_a_1664626272_3212880686_p_9};
	xsi_register_didat("work_a_1664626272_3212880686", "isim/TEST_MODULE_isim_beh.exe.sim/work/a_1664626272_3212880686.didat");
	xsi_register_executes(pe);
}
